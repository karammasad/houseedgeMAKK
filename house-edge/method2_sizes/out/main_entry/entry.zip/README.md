# House Edge entry

- Method: `method2_sizes` with settings `{"sizes": "gate", "gate_cell_prior": "npmle", "gate_couple": true, "gate_couple_iters": 20, "gate_tied": true, "gate_tie_weight": "learn", "gate_joint_em": true, "win_model": "adi", "win_kwargs": {"max_lag": 12, "and_pairs": true, "prior_flips": true, "prune": 0.01, "floor": 0.05, "cell_prior": "learn", "cell_group": "type", "p_change_short": "learn", "size_split": true, "cell_signal": true}}` (see entry_config.json)
- Environment: "python" image, Python 3.13, standard library only
- Forecast SHA-256: 56c5cd558ce950c2b736787692c907006b6e70d02c718a8595bb69947ed07f2e

Recreate: `python predict.py --data /data --out /output/submission.csv` (run from this folder).
It refits from `/data/train` (deterministic, no randomness) and predicts `/data/test`. No saved checkpoint is needed.
