"""Organizer entry point: python predict.py --data /data --out /output/submission.csv
Two saved models, each run in its own Python process from its own folder (member_a/, member_b/); their test forecasts are
averaged: P = W * A + (1 - W) * B. No retraining. Scratch files go to the system temp folder (/tmp)."""
import argparse, json, os, subprocess, sys, tempfile
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
W = 0.5
CHILD = '\nimport json, os, pickle, sys\nroot, data, out = sys.argv[1], sys.argv[2], sys.argv[3]\nsys.path.insert(0, root); sys.dont_write_bytecode = True\nfrom common.data import public_dir\nwith open(os.path.join(root, "checkpoint.pkl"), "rb") as f:\n    m = pickle.load(f)\nif hasattr(m, "set_workers"):\n    m.set_workers(2)\nif hasattr(m, "workers"):\n    m.workers = 2\ninner = getattr(m, "inner", None)\nif inner is not None and hasattr(inner, "workers"):\n    inner.workers = 2\nwith open(out, "w") as f:\n    json.dump(m.predict(public_dir(data), "test"), f)\n'
ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--out", required=True)
a = ap.parse_args()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    env[v] = "2"
preds = []
with tempfile.TemporaryDirectory() as tmp:
    for member in ("member_a", "member_b"):
        root = os.path.join(HERE, member); out = os.path.join(tmp, member + ".json")
        env_m = dict(env, PYTHONPATH=root)
        subprocess.run([sys.executable, "-c", CHILD, root, os.path.abspath(a.data), out], cwd=root, env=env_m, check=True)
        with open(out) as f:
            preds.append(json.load(f))
A, B = preds
P = {k: [W * x + (1 - W) * y for x, y in zip(A[k], B[k])] for k in A}
os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
with open(a.out, "w", newline="") as f:
    f.write("query_id,p_0,p_1,p_2,p_5,p_20\r\n")
    for k in sorted(P):
        f.write(",".join([k] + [format(v, ".17g") for v in P[k]]) + "\r\n")
