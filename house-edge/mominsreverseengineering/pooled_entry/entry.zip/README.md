# House Edge entry: 50/50 pool of two saved models

Recreate the forecast (run from this folder):

    python predict.py --data /data --out /output/submission.csv

- Expected output SHA-256: `0d0984e5a344fd8f723e80415aad65be0fdbb3df669c434efcfe4eec26025642`
- Model: P = 0.5 * A + 0.5 * B over [p0, p1, p2, p5, p20] (weight fixed in advance, not tuned).
  - A = `member_a/` (a): its own code copy + `checkpoint.pkl` (8.1 MB).
  - B = `member_b/` (b): its own code copy + `checkpoint.pkl` (0.1 MB).
  Both were fitted on `<data>/train` (labels + histories) and the HISTORIES of validation and test (no validation answers),
  then saved. predict.py runs each member in its own Python process (they ship different versions of the same packages),
  then averages. No retraining at prediction time.
- Dependencies (`requirements.txt`, exact versions used to fit and pickle the checkpoints): scikit-learn==1.8.0, numpy==2.4.4, scipy==1.17.1, joblib==1.5.3, threadpoolctl==3.6.0.
  Built with Python 3.13.7.
- Parallelism: 2 workers, 2 BLAS/OpenMP threads per member; results do not depend on it. Local rerun time: 242 s.
- Seeds: fixed everywhere; reruns are byte-identical. Writes only the `--out` file (plus temporary files in /tmp).
