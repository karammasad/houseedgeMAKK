"""Organizer entry point: python predict.py --data /data --out /output/submission.csv"""
import argparse, importlib, json, os, sys
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from common.data import public_dir, write_predictions
ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--out", required=True)
a = ap.parse_args()
with open(os.path.join(HERE, "entry_config.json")) as f:
    cfg = json.load(f)
pub = public_dir(a.data)
model = importlib.import_module(cfg["method"] + ".model").Model(**cfg["kwargs"]).fit(pub)
write_predictions(a.out, model.predict(pub, "test"))
