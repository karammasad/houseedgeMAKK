# House Edge entry

- Method: `adi.stack` with settings `{}` (see entry_config.json)
- Environment: "python" image, Python 3.13, standard library only
- Forecast SHA-256: 4454dc7af5007fc7f318571e2018565a753cb683a8457572f6602ece7f9944f8

Recreate: `python predict.py --data /data --out /output/submission.csv` (run from this folder).
It refits from `/data/train` (deterministic, no randomness) and predicts `/data/test`. No saved checkpoint is needed.
