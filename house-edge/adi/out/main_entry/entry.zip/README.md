# House Edge entry

- Method: `adi.sizewin` with settings `{}` (see entry_config.json)
- Environment: "python" image, Python 3.13, standard library only
- Forecast SHA-256: 1ddc8832b7a519d2b1a59fc52a8b9d4db91570b76ae31ed3a3365f1f03269b84

Recreate: `python predict.py --data /data --out /output/submission.csv` (run from this folder).
It refits from `/data/train` (deterministic, no randomness) and predicts `/data/test`. No saved checkpoint is needed.
